package pojos;

public enum Role {
	CUSTOMER, ADMIN
}
