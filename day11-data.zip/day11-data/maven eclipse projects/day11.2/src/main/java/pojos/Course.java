package pojos;
//courses  Table columns : id,title, start_date , end_date , fees , capacity

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Course extends BaseEntity {
	private String title;
	private LocalDate startDate;
	private LocalDate endDate;
	private double fees;
	private int capacity;
	// if u want to establish one ---> many association(HAS-A) between course n student , do u
	// need to add any additional property ? YES 
	private List<Student> students=new ArrayList<>();

	public Course() {
		// TODO Auto-generated constructor stub
	}

	public Course(String title, LocalDate startDate, LocalDate endDate, double fees, int capacity) {
		super();
		this.title = title;
		this.startDate = startDate;
		this.endDate = endDate;
		this.fees = fees;
		this.capacity = capacity;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public double getFees() {
		return fees;
	}

	public void setFees(double fees) {
		this.fees = fees;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

	@Override
	public String toString() {
		return "Course Id " + getId() + "[title=" + title + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", fees=" + fees + ", capacity=" + capacity + "]";
	}

}
