package pojos;
//students Table columns : id,name,email  + Foreign Key(FK) : course_id
public class Student extends BaseEntity{
	private String name;
	private String email;
	//what should be the addiotnal prop for mapping ? 
	private Course chosenCourse;
	public Student() {
		// TODO Auto-generated constructor stub
	}
	public Student(String name, String email) {
		super();
		this.name = name;
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	public Course getChosenCourse() {
		return chosenCourse;
	}
	public void setChosenCourse(Course chosenCourse) {
		this.chosenCourse = chosenCourse;
	}
	@Override
	public String toString() {
		return "Student ID "+getId()+"[name=" + name + ", email=" + email + "]";
	}
	
	

}
