package com.app.pojos;

public enum AcctType {
	SAVING, CURRENT, FD, LOAN
}
