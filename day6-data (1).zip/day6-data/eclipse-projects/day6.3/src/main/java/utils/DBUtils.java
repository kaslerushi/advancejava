package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtils {
	private static Connection cn;// null
	// add a static method to return SINGLETON (=single instance in the entire Java
	// App) to the caller

	public static Connection getConnection() throws SQLException {
		return cn;
	}

	public static void openConnection(String url, String userName, String password) throws SQLException {
		cn = DriverManager.getConnection(url, userName, password);
	}

	// add a static method to close connection.
	public static void closeConnection() throws SQLException {
		if (cn != null)
			cn.close();
	}

}
