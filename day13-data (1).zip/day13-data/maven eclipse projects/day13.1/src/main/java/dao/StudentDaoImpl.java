package dao;

import pojos.Address;
import pojos.AdharCard;
import pojos.Course;
import pojos.EducationalQualifications;
import pojos.Student;
import static utils.HibernateUtils.getFactory;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class StudentDaoImpl implements IStudentDao {

	@Override
	public String admitNewStudent(String courseName, Student s) {
		String jpql = "select c from Course c where c.title=:name";
		String mesg = "student admission failed";
		// get session from SF
		Session session = getFactory().getCurrentSession();
		// begin tx
		Transaction tx = session.beginTransaction();
		try {
			// get PERSISTENT Course POJO from the course name
			Course c = session.createQuery(jpql, Course.class).setParameter("name", courseName).getSingleResult();
			// =>valid course name(title) => course exists!
			// c : PERSISTENT
			c.addStudent(s);// modifying state of persistent entity
			// session.persist(s); no longer required : since added cascading !
			tx.commit();// hib auto dirty chking : due to cascading --insertion of a rec in students
						// tbale
			mesg = "student admission successful";
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

	@Override
	public String cancelAdmission(String courseTitle, int studentId) {
		String mesg = "Cancelling admission failed";
		String jpql = "select c from Course c where c.title=:name";
		Session session = getFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		try {
			// get PERSISTENT Course POJO from the course name
			Course c = session.createQuery(jpql, Course.class).setParameter("name", courseTitle).getSingleResult();
			// =>valid course name(title) => course exists!
			// c : PERSISTENT
			// get student from it's id
			Student s = session.get(Student.class, studentId);
			if (s != null) {
				c.removeStudent(s);
				mesg = "Cancelled admission for student " + s.getName();
			}
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

	@Override
	public String linkAdharCard(int studentId, AdharCard card) {
		String mesg = "Linking adhar card failed!!!!!";
		Session session = getFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		try {
			// get persistent student ref from its id
			Student s = session.get(Student.class, studentId);
			if (s != null) {
				// s : PERSISTENT
				s.setCard(card);
				mesg = "Linking adhar card successful";
			}
			tx.commit();// update
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}

		return mesg;
	}

	@Override
	public List<String> getStudentNamesByAdharCardCreationDate(LocalDate start1, LocalDate end1) {
		List<String> names=null;
		String jpql="select s.name from Student s where s.card.creationDate between :start and :end";

		Session session = getFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		try {
			names=session.createQuery(jpql, String.class).
					setParameter("start",start1).
					setParameter("end",end1).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return names;
	}

	@Override
	public String insertCompleteStudentDetails(String email, Address a, AdharCard card, List<String> hobbies,
			List<EducationalQualifications> qualifications) {
		String mesg="Insertion of complete details failed...";
		String jpql="select s from Student s where s.email=:em";
		Session session = getFactory().getCurrentSession();
		Transaction tx = session.beginTransaction();
		try {
			//get persistent student ref : email (jpql)
			Student s=session.createQuery(jpql, Student.class).setParameter("em", email).getSingleResult();//select
			//=> s : PERSISTENT
			//link student's address, address ---> student
			//first link adr --> student 
			a.setStudent(s);//comment this line : try it out in the lab : id generation exc.
			session.persist(a);
			//link adhar card
			s.setCard(card);
			//link hobbies 
			s.setHobbies(hobbies);
			//link edu qualifications
			s.setQualifications(qualifications);			
			tx.commit();//sql : insert : adr , hobbies, qualifications , update : student
			mesg="Insertion of complete details successful";
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}
	

}
