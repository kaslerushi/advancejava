package pojos;

public enum EduType {
	CBSC, HSC, DIPLOMA, DEGREE
}
