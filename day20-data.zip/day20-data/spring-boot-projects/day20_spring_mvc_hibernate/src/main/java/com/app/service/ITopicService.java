package com.app.service;

import java.util.List;

import com.app.pojos.Topic;


public interface ITopicService {
	//add a method to get list of topics
	List<Topic> getAllTopics();
}
