package pojos;

public enum Role {
	CUSTOMER, MODERATOR, ADMIN, SUPPLIER
}
