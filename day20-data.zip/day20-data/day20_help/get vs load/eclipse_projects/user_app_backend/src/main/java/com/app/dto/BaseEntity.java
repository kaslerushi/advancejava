package com.app.dto;



import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaseEntity {
	
	private Integer id;

	
	private int version;
}
