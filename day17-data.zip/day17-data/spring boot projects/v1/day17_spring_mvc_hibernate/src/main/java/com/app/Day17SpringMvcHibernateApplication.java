package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day17SpringMvcHibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day17SpringMvcHibernateApplication.class, args);
	}

}
