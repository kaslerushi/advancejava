package com.app.service;

import java.util.List;

public interface ITutorialService {
List<String> getTutorialsByTopic(int topicId);
}
