package tester;

import dependency.HttpTransport;
import dependent.ATMImpl;

public class TestATM {

	public static void main(String[] args) {
		//create dependent obj : ATMImpl
	//	ATMImpl atm=new ATMImpl(new HttpTransport());
	//	atm.deposit(1000);
		

	}

}
