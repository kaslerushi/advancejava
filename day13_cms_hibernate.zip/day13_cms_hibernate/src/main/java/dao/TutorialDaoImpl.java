package dao;

import java.sql.SQLException;
import java.util.List;

import pojos.Tutorial;

public class TutorialDaoImpl implements ITutorialDao {

	@Override
	public List<String> getTutorialsByTopicId(int topicId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Tutorial getTutorialDetails(String tutName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateVisits(String tutName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addNewTutorial(Tutorial tutorial,int topicId)  {
		// TODO Auto-generated method stub
		return null;
	}
	
}
