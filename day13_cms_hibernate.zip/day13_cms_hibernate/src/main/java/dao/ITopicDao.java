package dao;

import java.util.List;

import pojos.Topic;

public interface ITopicDao {
	List<Topic> getAllTopics();
}
