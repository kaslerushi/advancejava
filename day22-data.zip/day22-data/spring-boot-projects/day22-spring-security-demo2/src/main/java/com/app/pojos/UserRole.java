package com.app.pojos;

public enum UserRole {
	ROLE_CUSTOMER, ROLE_ADMIN
}
