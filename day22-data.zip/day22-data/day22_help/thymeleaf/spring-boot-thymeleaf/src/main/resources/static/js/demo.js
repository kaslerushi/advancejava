function showAlert() {
    alert("The button was clicked!");
}