package com.app.pojos;

public enum UserRole {
	ADMIN, CUSTOMER
}
